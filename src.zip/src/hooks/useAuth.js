// src/hooks/useAuth.js
import { useEffect, useState } from 'react';
import { supabase } from '../supabase/supabaseConfig';
import { useDispatch } from 'react-redux';
import { setTasks } from '../features/checkboxList/taskSlice';
import { getAllTasks } from '../services/taskService';

export const useAuth = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const dispatch = useDispatch();

  useEffect(() => {
    let isMounted = true;

    const checkAuth = async () => {
      try {
        console.log('🔍 شروع بررسی authentication...');
        
        // ابتدا session رو چک کنیم
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        console.log('📋 Session:', session);
        console.log('❌ Session Error:', sessionError);

        if (sessionError) {
          console.error("خطا در دریافت session:", sessionError);
        }

        // سپس user رو چک کنیم
        const { data: { user: currentUser }, error: userError } = await supabase.auth.getUser();
        console.log('👤 Current User:', currentUser);
        console.log('❌ User Error:', userError);

        if (userError && userError.message !== 'Auth session missing!') {
          console.error("خطا در دریافت کاربر:", userError);
        }

        if (!isMounted) return;

        if (currentUser) {
          console.log('✅ کاربر احراز هویت شده:');
          console.log('   - ID:', currentUser.id);
          console.log('   - Email:', currentUser.email);
          console.log('   - User Metadata:', currentUser.user_metadata);
          console.log('   - App Metadata:', currentUser.app_metadata);
          
          setUser(currentUser);
          
          // بارگذاری تسک‌ها
          console.log('📥 شروع بارگذاری تسک‌ها...');
          try {
            const tasks = await getAllTasks();
            console.log('✅ تسک‌های دریافت شده:', tasks);
            console.log('📊 تعداد تسک‌ها:', tasks.length);
            
            if (isMounted) {
              dispatch(setTasks(tasks));
              console.log('✅ تسک‌ها در Redux ذخیره شدند');
            }
          } catch (taskError) {
            console.error("❌ خطا در دریافت تسک‌ها:", taskError);
            if (isMounted) {
              dispatch(setTasks([]));
            }
          }
        } else {
          console.log('❌ کاربر وارد نشده است');
          setUser(null);
          dispatch(setTasks([]));
        }

        if (isMounted) {
          setLoading(false);
          console.log('✅ Loading تمام شد');
        }
      } catch (error) {
        console.error("❌ خطای کلی در authentication:", error);
        if (isMounted) {
          setUser(null);
          dispatch(setTasks([]));
          setLoading(false);
        }
      }
    };

    // اجرای اولیه
    checkAuth();

    // گوش دادن به تغییرات auth
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!isMounted) return;

        console.log('🔄 Auth State Change:');
        console.log('   - Event:', event);
        console.log('   - Session User:', session?.user?.email || 'بدون کاربر');

        if (event === 'SIGNED_IN' && session?.user) {
          console.log('✅ کاربر وارد شد:', session.user.email);
          setUser(session.user);
          
          try {
            const tasks = await getAllTasks();
            console.log('✅ تسک‌های جدید دریافت شد:', tasks.length);
            if (isMounted) {
              dispatch(setTasks(tasks));
            }
          } catch (error) {
            console.error("❌ خطا در دریافت تسک‌ها در auth change:", error);
            if (isMounted) {
              dispatch(setTasks([]));
            }
          }
        } else if (event === 'SIGNED_OUT') {
          console.log('🚪 کاربر خارج شد');
          setUser(null);
          dispatch(setTasks([]));
        }

        if (isMounted) {
          setLoading(false);
        }
      }
    );

    return () => {
      console.log('🧹 Cleanup useAuth');
      isMounted = false;
      subscription?.unsubscribe();
    };
  }, [dispatch]);

  // Debug info در هر render
  console.log('🎯 useAuth State:', {
    user: user ? {
      id: user.id,
      email: user.email,
      metadata: user.user_metadata
    } : null,
    loading
  });

  return { user, loading };
};