import { useState } from "react";
import { Box, IconButton, useMediaQuery, Drawer } from "@mui/material";
import MenuIcon from "@mui/icons-material/Menu";
import CategoryDrawer from "../features/category/CategoryDrawer/CategoryDrawer";
import CheckboxList from "../features/checkboxList/CheckboxList";
import DateTimeDisplay from "../components/dateTime/DateTime";
import CreateTask from "../features/createTask/CreateTask";
import TaskDateFilter from "../features/checkboxList/TaskDateFilter";
import "../App.css";
import LogoutButton from "../components/logout/LogoutButton";

function  Home() {
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedCategory, setSelectedCategory] = useState(null);
  const [mobileOpen, setMobileOpen] = useState(false);

  const isDesktop = useMediaQuery("(min-width:1024px)");

  const handleDateChange = (newDate) => setSelectedDate(newDate);
  const handleCategorySelect = (categoryId) => setSelectedCategory(categoryId);
  const toggleDrawer = () => setMobileOpen(!mobileOpen);

  return (
    <div className="App">
      <div className="App-body">
        {!isDesktop && (
          <IconButton
            onClick={toggleDrawer}
            sx={{ position: "absolute", top: 10, left: 10 }}
          >
            <MenuIcon />
          </IconButton>
        )}

        {isDesktop ? (
          <CategoryDrawer onCategorySelect={handleCategorySelect} />
        ) : (
          <Drawer open={mobileOpen} onClose={toggleDrawer}>
            <CategoryDrawer
              onCategorySelect={(id) => {
                handleCategorySelect(id);
                setMobileOpen(false); // بستن دراور بعد از انتخاب
              }}
            />
          </Drawer>
        )}

        <Box className="App-checkbox">
          <Box
            className="header-box"
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              mb: 2,
            }}
          >
            <DateTimeDisplay />
            <TaskDateFilter onDateChange={handleDateChange} />
          </Box>

          <div className="checkbox-list-container">
            <CheckboxList
              selectedDate={selectedDate}
              selectedCategory={selectedCategory}
            />
          </div>

          <div className="footer-box">
            <CreateTask />
            {/* <LogoutButton/> */}
          </div>
        </Box>
      </div>
    </div>
  );
}

export default Home;
